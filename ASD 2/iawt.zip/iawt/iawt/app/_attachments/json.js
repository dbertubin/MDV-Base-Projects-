
 json = {
                "task1" : {
                              "groups" : ["Group:" , "current"],
                              "taskName" : ["Task Name:", "Test App"],
                              "taskLength" : ["Task Length:", "30"],
                              "completeBy" : [ "Complete By:", "2011-12-12"],
                              "notes": ["Notes:", "Notes go here!"]    
                } ,
                "task2" : {
                              "groups" : ["Group:" , "current"],
                              "taskName" : ["Task Name:", "Test Clear Data"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2011-12-12"],
                              "notes": ["Notes:", "Notes go here again!"]   
                } ,
                "task3" :{
                             "groups" : ["Group:" , "future"],
                              "taskName" : ["Task Name:", "Record Reflection"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2011-12-12"],
                              "notes": ["Notes:", "Notes go here again!"]                 
               },
               "task4" : {
                              "groups" : ["Group:" , "collabrative"],
                              "taskName" : ["Task Name:", "Change the World"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-12-21"],
                              "notes": ["Notes:", "Before it ends"]    
               },
               "task5" :{
                              "groups" : ["Group:" , "sharedbucket"],
                              "taskName" : ["Task Name:", "Stop and Smell the Roses"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-02-21"],
                              "notes": ["Notes:", "Do it before they die!"]  
               },
               "task6" :{
                              "groups" : ["Group:" , "bucket"],
                              "taskName" : ["Task Name:", "Work on Personal Relationships"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-04-14"],
                              "notes": ["Notes:", "For a happier tomorrow "]  
               },
               "task7" :{
                              "groups" : ["Group:" , "bucket"],
                              "taskName" : ["Task Name:", "Work on Personal Relationships"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-04-14"],
                              "notes": ["Notes:", "For a happier tomorrow "]  
               },
               "task8" : {
                              "groups" : ["Group:" , "collabrative"],
                              "taskName" : ["Task Name:", "Go to the Movies"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-04-15"],
                              "notes": ["Notes:", "Want to see Hunger Games. "]    
               },
               "task9" : {
                              "groups" : ["Group:" , "collabrative"],
                              "taskName" : ["Task Name:", "Start Kick Boxing"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-05-15"],
                              "notes": ["Notes:", "To work of my Thai Curry! "]  
               },
               "task10" : {
                              "groups" : ["Group:" , "collabrative"],
                              "taskName" : ["Task Name:", "Start Kick Boxing"],
                              "taskLength" : ["Task Length:", "2"],
                              "completeBy" : [ "Complete By:", "2012-05-15"],
                              "notes": ["Notes:", "To work of my Thai Curry! "]  
               }
 };             